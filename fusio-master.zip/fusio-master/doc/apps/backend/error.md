
## Error

Lists all errors which occurred on the endpoints. The detail view shows the 
message and the stack trace of the error. 
