
## Import

The importer provides a way to import route and schema definitions. The data 
must be in the [OpenAPI], [RAML] or [Swagger] format. The importer displays a 
preview what data is imported before any changes are made.

[OpenAPI]: https://www.openapis.org/
[RAML]: https://raml.org/
[Swagger]: https://swagger.io/
