
Swagger-UI
==========

.. image:: ../_static/swagger-ui.png

The `swagger-ui`_ app renders a documentation based on the OpenAPI
specification. The app is located at ``/swagger-ui/``.

.. _swagger-ui: https://github.com/swagger-api/swagger-ui
