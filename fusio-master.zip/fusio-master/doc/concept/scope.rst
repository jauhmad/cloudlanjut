
Scope
=====

A scope describes the right to access specific routes and request methods. Each
user account has assigned a set of allowed scopes. If a user creates an app he 
can only assign the scopes which are available for him.

