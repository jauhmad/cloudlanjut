<?php

declare(strict_types = 1);

namespace App\Model;

/**
 * @extends Collection<Todo>
 */
class Todo_Collection extends Collection
{
}
