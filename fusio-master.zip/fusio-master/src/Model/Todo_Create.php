<?php

declare(strict_types = 1);

namespace App\Model;

/**
 * @Required({"title"})
 */
class Todo_Create extends Todo implements \JsonSerializable
{
}
